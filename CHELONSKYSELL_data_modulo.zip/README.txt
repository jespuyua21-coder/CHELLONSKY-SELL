Módulo base CHELONSKYSELL

Este archivo será la base para:
- Clientes
- Ventas
- Inventario
- Cobranza
- Cortes diarios y semanales

Agregarlo al proyecto junto con los archivos actuales.
